/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 01:25:15 by pzau              #+#    #+#             */
/*   Updated: 2024/07/16 05:49:27 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	enviar_bit(pid_t pid, char *str)
{
	int	i;
	int	bit;

	while (*str)
	{
		i = 8;
		while (i--)
		{
			bit = ((*str >> i) & 1);
			if (bit == 0)
				kill(pid, SIGUSR1);
			else
				kill(pid, SIGUSR2);
			usleep(1000);
		}
		++str;
	}
}

int	main(int a, char **b)
{
	if (a == 3)
	{
		ft_printf("Conectado ao servidor: %d\n", ft_atoi(b[1]));
		enviar_bit(ft_atoi(b[1]), ft_strjoin(b[2], "\n"));
	}
	else
	{
		ft_printf("Numero de algumentos incorretos\n");
		ft_printf("Apenas aceitamos 2 argumentos\n");
		return (1);
	}
	return (0);
}
