/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   write_p.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/24 17:56:42 by pzau              #+#    #+#             */
/*   Updated: 2024/05/26 22:50:36 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	write_p(void *ptr, size_t *i)
{
	unsigned long	p;
	char			*str;

	if (ptr == NULL)
	{
		write_s("(nil)", i);
		return ;
	}
	p = (unsigned long)ptr;
	write_s("0x", i);
	str = auxilary_func(p, HEL_LOW_BASE);
	write_s(str, i);
	free(str);
}
