/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 10:17:01 by pzau              #+#    #+#             */
/*   Updated: 2024/07/16 05:38:44 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	ligado(void)
{
	printf("   ******  ******  ******    **      **  ******  ******\n");
	printf("   ******  ******  ******    **      **  ******  ******\n");
	printf("   **      **      **    **  **      **  **      **    **\n");
	printf("   ******  ******  **    **  **      **  ******  **    **\n");
	printf("   ******  ******  *******   **      **  ******  *******\n");
	printf("       **  **      **   **    **    **   **      **   **\n");
	printf("   ******  ******  **   **     **  **    ******  **   **\n");
	printf("   ******  ******  **   **      ****     ******  **   **\n");
}

void	bit_converter(int sig)
{
	static int	bit = 0;
	static char	c = 0;

	c <<= 1;
	c |= (sig == SIGUSR2);
	bit++;
	if (bit == 8)
	{
		ft_printf("%c", c);
		c = 0;
		bit = 0;
	}
}

int	main(void)
{
	ft_printf("\n");
	ft_printf("\n");
	ligado();
	ft_printf("\n");
	ft_printf("   Este e o meu PID: %d\n\n", getpid());
	signal(SIGUSR1, bit_converter);
	signal(SIGUSR2, bit_converter);
	while (1)
		pause();
	return (0);
}
