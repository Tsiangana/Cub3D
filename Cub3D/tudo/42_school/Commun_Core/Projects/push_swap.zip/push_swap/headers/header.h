/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/30 11:54:46 by pzau              #+#    #+#             */
/*   Updated: 2024/08/30 11:54:47 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H

# include "../ft_printf/ft_printf.h"
# include "../libft/libft.h"
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <ctype.h>
# include <limits.h>

# define NA 0
# define TO_UP 1
# define TO_DOWN 2
# define GO_TOGETHER 3
# define GO_ALONE 4

typedef struct  s_node
{
    int value;
    int index;
    struct s_node *previous;
}   t_node;

typedef struct s_stack
{
    int total;
    t_node  *top;
    t_node  *bottom;
}   t_stack;

typedef struct s_vars
{
    t_stack     *a;
    t_stack     *b;
    int total_operations;
}   t_vars;

typedef struct s_input_values
{
    int total;
    char    **matriz;
}   t_input_values;

typedef struct  s_main_init
{
    t_input_values  input;
    int     *values;
}   t_main_init;

typedef struct s_pre_cost {
    int     up_target;
    int     down_target;
    int     up_pivot;
    int     down_pivot;
    t_node  *target;
    t_node  *pivot;
}       t_pre_cost;

typedef struct s_cost_go_together {
	int	cost;
	int	to;
}		t_cost_go_together;

typedef struct s_cost_go_alone {
	int	cost;
	int	pivot_to;
	int	target_to;
}		t_cost_go_alone;

typedef struct s_cost_result {
	t_cost_go_together	together;
	t_cost_go_alone		alone;
	t_node				*pivot;
	t_node				*target;
	int					cost;
	int					go;
	int					operations;
}		t_cost_result;

t_vars  *init_vars(t_input_values result, int *values);
t_cost_result   find_cheapest(t_stack *sp, t_stack *st);
t_cost_result   find_cost(t_stack *sp, t_stack *st, t_node *pivot);
t_cost_go_alone set_info_alone(int cost, int pivot_to, int target_to);
t_node  *find_min(t_stack *stack);
t_node  *find_max(t_stack *stack);
t_node  *find_target(t_stack *stack, t_node *pivot);
t_node  *find_min_closest(t_stack *stack, int pivot);

void    dispose(t_vars *vars);
void    sort_all_b(t_vars *vars);
void    sort_all_a(t_vars *vars);
void    sa(t_vars *vars);
void    sb(t_vars *vars);
void    ss(t_vars *vars);
void    pa(t_vars *vars);
void    pb(t_vars *vars);
void    rra(t_vars *vars);
void    rrb(t_vars *vars);
void    rrr(t_vars *vars);
void    ra(t_vars *vars);
void    rb(t_vars *vars);
void    rr(t_vars *vars);
void    print_a(t_vars *vars);
void    print_b(t_vars *vars);
void    two_or_three(t_vars *vars);
void    org_three(t_vars *vars);
void    org_five(t_vars *vars);
void    org_two(t_vars *vars, int pilha);
void    free_stack(t_stack *stack);
void    sort_3(t_vars *vars);
void    set_target_pivot(t_cost_result *result, t_node *target, t_node *pivot);
int is_number(char *str);
int *to_array(char **matriz, int total, int *has_error);
int has_duplicate(int *result, int total);
int is_sorted(int *result, int total);
int push(t_stack *stack, int value);
int pop(t_stack *stack);
int total(t_vars *vars);
int max_value(t_stack *stack);
int min_value(t_stack *stack);
int get_half(t_stack *stack);
int get_max_value(int n1, int n2);

#endif
