/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   count_words.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 21:01:38 by pzau              #+#    #+#             */
/*   Updated: 2024/09/03 21:02:00 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int count_words(char *str)
{
    int count;
    int wc;

    if (str == NULL)
        return (0);
    wc = 0;
    count = 0;
    while (str[count])
    {
        while (str[count] && (str[count] == ' ' || str[count] == '\t' || str[count]  == '\n'))
            count++;
        if (str[count])
            wc++;
        while (str[count] && (str[count] != ' ' && str[count] !=  '\t' && str[count] != '\n'))
            count++;
    }
    return (wc);
}
