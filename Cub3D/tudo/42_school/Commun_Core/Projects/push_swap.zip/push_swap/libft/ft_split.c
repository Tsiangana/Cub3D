/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 11:51:20 by pzau              #+#    #+#             */
/*   Updated: 2024/09/07 11:51:22 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int ft_count_words(char *str)
{
    int i;
    int wc;

    if (str == NULL)
        return (0);
    i = 0;
    wc = 0;
    while (str[i])
    {
        while (str[i] && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'))
            i++;
        if (str[i])
            wc++;
        while (str[i] && (str[i] != ' ' && str[i] != '\t' && str[i] != '\n'))
            i++;
    }
    return (wc);
}

static char *ft_strncpy_alloc(char *src, int n)
{
    char    *dest;
    int     i;

    dest = (char *)malloc(sizeof(char) * (n + 1));
    if (dest == NULL)
        return (NULL);
    i = 0;
    while (i < n)
    {
        dest[i] = src[i];
        i++;
    }
    dest[n] = '\0';
    return (dest);
}

static char **allocate_words(char *str, int wc)
{
    char    **out;
    int     i;
    int     j;
    int     k;

    i = 0;
    j = 0;
    k = 0;
    out = (char **)malloc(sizeof(char *) * (wc + 1));
    if (out == NULL)
        return (NULL);
    while (str[i])
    {
        while (str[i] && (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'))
            i++;
        j = i;
        while (str[i] && (str[i] != ' ' && str[i] != '\t' && str[i] != '\n'))
            i++;
        if (i > j)
            out[k++] = ft_strncpy_alloc(&str[j], i - j);
    }
    out[k] = NULL;
    return (out);
}

char    **ft_split(char *str)
{
    int     wc;
    char    **out;

    wc = ft_count_words(str);
    out = allocate_words(str, wc);
    return (out);
}

void	free_split(char **matrix)
{
	int	i;

	i = 0;
	if (matrix)
	{
		while (matrix[i])
		{
			free(matrix[i]);
			i++;
		}
		free(matrix);
	}
}
