/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/30 11:57:45 by pzau              #+#    #+#             */
/*   Updated: 2024/08/30 11:57:47 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H

# include <stdlib.h>
# include <string.h>

void	free_split(char **matrix);
char	**ft_split(char *str);
char    *ft_strdup(char *str);
char    *ft_strjoin(char *s1, char *s2);
char    *ft_strncpy(char *s1, char *s2, int n);
int count_words(char *str);
int	ft_strlen(char *str);
long long	ft_atoi(const char *str);

#endif
