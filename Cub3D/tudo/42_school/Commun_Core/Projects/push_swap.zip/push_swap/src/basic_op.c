/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   basic_op.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 07:04:57 by pzau              #+#    #+#             */
/*   Updated: 2024/09/11 07:05:02 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

void    two_or_three(t_vars *vars)
{
    if (total(vars) == 2)
    {
        org_two(vars, 1);
    }
    else if (total(vars) == 3)
    {
        org_three(vars);
    }
    else if (total(vars) == 5 || total(vars) == 4)
    {
        org_five(vars);
    }
    else
        return ;
    return ;
}
