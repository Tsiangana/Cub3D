/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_value.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 08:33:43 by pzau              #+#    #+#             */
/*   Updated: 2024/09/11 08:33:44 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

int max_value(t_stack *stack)
{
    t_node  *current;
    int max_value;

    if (stack == NULL || stack->top == NULL)
        return (-1);
    current = stack->top;
    max_value = current->value;
    while (current)
    {
        if (current->value > max_value)
            max_value = current->value;
        current = current->previous;
    }

    return (max_value);
}

int min_value(t_stack *stack)
{
    t_node  *current;
    int min_value;

    if (stack == NULL || stack->top == NULL)
        return (-1);
    current = stack->top;
    min_value = current->value;
    while (current)
    {
        if (current->value < min_value)
            min_value = current->value;
        current = current->previous;
    }
    return (min_value);
}

t_node  *find_min(t_stack *stack)
{
    t_node  *current;
    t_node  *min_value;

    if (stack->top == NULL)
        return (NULL);
    current = stack->top;
    min_value = current;
    while (current != NULL)
    {
        if (current->value < min_value->value)
            min_value = current;
        current = current->previous;
    }
    return (min_value);
}

t_node  *find_max(t_stack *stack)
{
    t_node  *current;
    t_node  *max_value;

    if (stack->top == NULL)
        return (NULL);
    current = stack->top;
    max_value = current;
    while (current != NULL)
    {
        if (current->value > max_value->value)
            max_value = current;
        current = current->previous;
    }
    return (max_value);
}

int get_half(t_stack *stack)
{
    int result;

    result = stack->total / 2;
    if (result % 2 != 0)
        return (result++);
    return (result);
}

void    set_target_pivot(t_cost_result *result, t_node *target, t_node *pivot)
{
    result->target = target;
    result->pivot = pivot;
}
