/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_vars.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 13:38:41 by pzau              #+#    #+#             */
/*   Updated: 2024/09/07 13:38:42 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static t_stack *init_stack(void)
{
    t_stack *stack;

    stack = (t_stack *)malloc(sizeof(t_stack));
    if (!stack)
        return (NULL);
    stack->total = 0;
    stack->top = NULL;
    stack->bottom = NULL;
    return (stack);
}

t_vars  *init_vars(t_input_values result, int *values)
{
    t_vars *vars;
    int i;

    vars = (t_vars *)malloc(sizeof(t_vars));
    if (!vars)
        exit(1);
    vars->a = init_stack();
    vars->b = init_stack();
    if (vars->a == NULL || vars->b == NULL)
        exit(0);
    vars->total_operations = 0;
    i = result.total - 1;
    while (i >= 0)
    {
        push(vars->a, values[i]);
        i--;
    }
    free_split(result.matriz);
    free(values);
    return (vars);
}

void    dispose(t_vars *vars)
{
    free_stack(vars->a);
    free_stack(vars->b);
    free(vars);
}
