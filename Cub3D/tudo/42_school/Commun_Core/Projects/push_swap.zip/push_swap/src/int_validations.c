/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   int_validations.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 12:27:19 by pzau              #+#    #+#             */
/*   Updated: 2024/09/07 12:27:20 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static  int is_with_range(char *str)
{
    long long new_numb;

    new_numb = ft_atoi(str);
    if (new_numb > INT_MAX || new_numb < INT_MIN)
        return (0);
    return (1);
}

int  is_number(char *str)
{
    int i;

    i = 0;
    while (str[i] == '-' || str[i] == '+')
        i++;
    while (str[i])
    {
        if (str[i] <  '0' || str[i] > '9')
            return (0);
        i++;
    }
    return (1);
}

int *to_array(char **matrix, int total, int *has_error)
{
    int *result;
    int i;

    *has_error = 1;
    if (!matrix || total <= 0)
        return (NULL);
    result = (int *)malloc(sizeof(int) * total);
    if (!result)
        return (NULL);
    *has_error = 0;
    i = 0;
    while (i < total)
    {
        if (!is_number(matrix[i]) || !is_with_range(matrix[i]))
        {
            *has_error = 1;
            free(result);
            return (NULL);
        }
        result[i] = ft_atoi(matrix[i]);
        i++;
    }
    return (result);
}

int has_duplicate(int *result, int total)
{
    int i;
    int j;

    i = 0;
    j = 0;
    if (result == NULL || total <= 1)
        return (0);
    while (i < (total - 1))
    {
        j = i + 1;
        while (j < total)
        {
            if (result[i] == result[j])
                return (1);
            j++;
        }
        i++;
    }
    return (0);
}

int is_sorted(int *result, int total)
{
    int i;

    if (total < 2)
        return (1);
    i = 1;
    while (i < total)
    {
        if (result[i - 1] > result[i])
            return (0);
        i++;
    }
    return (1);
}
