/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/30 12:22:47 by pzau              #+#    #+#             */
/*   Updated: 2024/08/30 12:24:25 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static char *join_all_parameters(int argc, char **argv)
{
    char    *values;
    int     total;
    int     i;

    i = 1;
    total = 0;
    while (i < argc)
        total += (ft_strlen(argv[i++]) + 1);
    values = (char *)malloc(sizeof(char) * total);
    if (!values)
        return (NULL);
    values[0] = '\0';
    i = 1;
    while (i < argc)
    {
        values = ft_strjoin(values, argv[i]);
        if (i != argc - 1)
            values = ft_strjoin(values, " ");
        i++;
    }
    return (values);
}

static t_input_values   get_values_by_string(char *str)
{
    t_input_values  result;

    result.total = 0;
    result.matriz = NULL;
    if (count_words(str) == 1)
        exit(1);
    result.matriz = ft_split(str);
    if (!result.matriz)
        return (result);
    result.total = count_words(str);
    free(str);
    return (result);
}

static void is_error(t_main_init result, int print, int fl)
{
    if (print)
        ft_printf("Error\n");
    free_split(result.input.matriz);
    if (fl)
        free(result.values);
    exit(1);
}

static  t_main_init parametrs(int ac, char **av)
{
    t_main_init result;
    int error;
    char        *parameters;

    if (ac == 1)
        exit(1);
    parameters = join_all_parameters(ac, av);
    result.input = get_values_by_string(parameters);
    result.values = to_array(result.input.matriz, result.input.total, &error);
    if (error)
        is_error(result, 1, 1);
    if (has_duplicate(result.values, result.input.total))
        is_error(result, 1, 1);
    if (is_sorted(result.values, result.input.total))
        is_error(result, 0, 1);
    return (result);
}

int main(int ac, char **av)
{
    t_vars *vars;
    t_main_init result;

    result = parametrs(ac, av);
    vars = init_vars(result.input, result.values);

    two_or_three(vars);
    if (vars->a->total > 5)
    {
        sort_all_b(vars);
        sort_all_a(vars);
    }
    //ft_printf("\nTotal: %d\n", vars->total_operations);
    dispose(vars);
    return (0);
}
