/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_one.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 23:29:41 by pzau              #+#    #+#             */
/*   Updated: 2024/09/10 23:29:43 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

void    pa(t_vars *vars)
{
    if (vars->b->top == NULL)
        return ;
    push(vars->a, pop(vars->b));
    ft_printf("pa\n");
    vars->total_operations++;
}

void    pb(t_vars *vars)
{
    if (vars->a->top == NULL)
        return ;
    push(vars->b, pop(vars->a));
    ft_printf("pb\n");
    vars->total_operations++;
}

void    print_a(t_vars *vars)
{
    ft_printf("Pilha a:\n");
    t_node *current = vars->a->top;
    while (current)
    {
        ft_printf("%d\n", current->value);
        current = current->previous;
    }
    ft_printf("Fim\n");
}

void    print_b(t_vars *vars)
{
    ft_printf("\nPilha b:\n");
    t_node *current_b = vars->b->top;
    while (current_b)
    {
        ft_printf("%d\n", current_b->value);
        current_b = current_b->previous;
    }
    ft_printf("Fim\n");
}

int total(t_vars *vars)
{
    int index;

    index = 0;
    t_node *current = vars->a->top;
    while (current)
    {
        index++;
        current = current->previous;
    }
    return (index);
}
