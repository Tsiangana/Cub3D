/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_push.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 14:30:39 by pzau              #+#    #+#             */
/*   Updated: 2024/09/07 14:30:41 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static  void    update_index(t_stack *stack)
{
    int i;
    t_node  *current;

    current = stack->top;
    i = 0;
    while (current)
    {
        current->index = i++;
        current = current->previous;
    }
}

int push(t_stack *stack, int value)
{
    t_node *new_node;

    new_node = (t_node *)malloc(sizeof(t_node));
    if (!new_node)
        return (0);
    new_node->value = value;
    new_node->index = 0;
    new_node->previous = stack->top;
    if (stack->total == 0)
        stack->bottom = new_node;
    stack->top = new_node;
    stack->total++;
    update_index(stack);
    return (1);
}

int pop(t_stack *stack)
{
    t_node *temp_node;
    int value;

    if (!stack->top)
        return (-1);
    temp_node = stack->top;
    value = temp_node->value;
    stack->top = stack->top->previous;
    if (stack->top == NULL)
        stack->bottom == NULL;
    free(temp_node);
    stack->total--;
    update_index(stack);
    return (value); 
}
