/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_r.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 00:43:08 by pzau              #+#    #+#             */
/*   Updated: 2024/09/11 00:43:10 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static int  rotate(t_stack *value)
{
    t_node  *temp;
    t_node  *last;

    if ((value->top == NULL) || (value->top->previous == NULL))
        return (0);
    temp = value->top;
    last =  temp;
    while (last->previous != NULL)
        last = last->previous;
    value->top = temp->previous;
    last->previous = temp;
    temp->previous = NULL;
    return (1);
}

void    ra(t_vars *vars)
{
    if (rotate(vars->a))
    {
        ft_printf("ra\n");
        vars->total_operations++;
    }
}

void    rb(t_vars *vars)
{
    if (rotate(vars->b))
    {
        ft_printf("rb\n");
        vars->total_operations++;
    }
}

void    rr(t_vars *vars)
{
    if ((vars->a->top == NULL) || (vars->b->top == NULL))
        return ;
    if ((vars->a->top->previous == NULL) || (vars->b->top->previous == NULL))
        return ;
    if ((rotate(vars->a) && (rotate(vars->b))))
    {
        ft_printf("rr\n");
        vars->total_operations++;
    }
}
