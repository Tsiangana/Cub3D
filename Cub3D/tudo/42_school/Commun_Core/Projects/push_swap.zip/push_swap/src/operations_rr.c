/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_r.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 23:38:07 by pzau              #+#    #+#             */
/*   Updated: 2024/09/10 23:38:09 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static int  reverse_aux(t_stack *value)
{
    t_node  *last;
    t_node  *second_last;

    if ((value->top == NULL) || (value->top->previous == NULL))
        return (0);
    second_last = value->top;
    while (second_last->previous->previous != NULL)
        second_last = second_last->previous;
    last = second_last->previous;
    second_last->previous = NULL;
    last->previous = value->top;
    value->top = last;
    return (1);
}

void    rra(t_vars *vars)
{
    if (reverse_aux(vars->a))
    {
        ft_printf("rra\n");
        vars->total_operations++;
    }
}

void    rrb(t_vars *vars)
{
    if (reverse_aux(vars->b))
    {
        ft_printf("rrb\n");
        vars->total_operations++;
    }
}

void    rrr(t_vars *vars)
{
    if ((vars->a->top == NULL) || (vars->b->top == NULL))
        return ;
    if ((vars->a->top->previous == NULL) || (vars->b->top->previous == NULL))
        return ;
    if ((reverse_aux(vars->a) && (reverse_aux(vars->b))))
    {
        ft_printf("rrr\n");
        vars->total_operations++;
    }
}
