/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_s.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 01:23:28 by pzau              #+#    #+#             */
/*   Updated: 2024/09/11 01:23:31 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static int  swap_aux(t_stack *value)
{
    t_node  *temp;

    if ((value->top == NULL) || (value->top->previous == NULL))
        return (0);
    temp = value->top;
    value->top = value->top->previous;
    temp->previous = value->top->previous;
    value->top->previous = temp;
    return (1);
}

void    sa(t_vars *vars)
{
    if (swap_aux(vars->a))
    {
        ft_printf("sa\n");
        vars->total_operations++;
    }
}

void    sb(t_vars *vars)
{
    if (swap_aux(vars->b))
    {
        ft_printf("sb\n");
        vars->total_operations++;
    }
}

void    ss(t_vars *vars)
{
    if ((vars->a->top == NULL) || (vars->b->top == NULL))
        return ;
    if ((vars->a->top->previous == NULL) || (vars->b->top->previous == NULL))
        return ;
    if ((swap_aux(vars->a)) && (swap_aux(vars->b)))
    {
        ft_printf("ss\n");
        vars->total_operations++;
    }
}
