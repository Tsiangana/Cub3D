/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   org_min_values.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 14:57:31 by pzau              #+#    #+#             */
/*   Updated: 2024/09/12 14:57:33 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static void move_min_to_top(t_vars *vars)
{
    t_node *min;

    min = find_min(vars->a);
    if (min->index <= get_half(vars->a))
    {
        while (vars->a->top->value != min->value)
            ra(vars);
    }
    else
    {
        while (vars->a->top->value != min->value)
            rra(vars);
    }
}

void    org_two(t_vars *vars, int pilha)
{
    if (pilha == 1)
        sa(vars);
    else if (pilha != 1)
        sb(vars);
}

void    org_three(t_vars *vars)
{
    int top;
    int bottom;
    int max;
    int min;

    top = vars->a->top->value;
    bottom = vars->a->top->previous->previous->value;
    max = max_value(vars->a);
    min = min_value(vars->a);
    if ((top == min) && (bottom != max))
    {
        sa(vars);
        ra(vars);
    }
    else if ((top != max) && (bottom == min))
        rra(vars);
    else if ((top != max) && (bottom == max))
        sa(vars);
    else if ((top == max) && (bottom == min))
    {
        sa(vars);
        rra(vars);
    }
    else if ((top == max) && (bottom != min))
        rra(vars);
}

void    org_five(t_vars *vars)
{
    while (vars->a->total > 3)
    {
        move_min_to_top(vars);
        pb(vars);
    }
    sort_3(vars);
    //pa(vars);
    //pa(vars);
}
