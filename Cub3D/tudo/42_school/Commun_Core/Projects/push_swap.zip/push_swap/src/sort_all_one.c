/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_all_one.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 01:29:42 by pzau              #+#    #+#             */
/*   Updated: 2024/09/13 01:29:44 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static void	move_max_to_top(t_vars *vars)
{
	t_node	*max;

	max = find_max(vars->b);
	if (max->index <= get_half(vars->b))
	{
		while (vars->b->top->index != max->index)
			rb(vars);
	}
	else
	{
		while (vars->b->top->index != max->index)
			rrb(vars);
	}
}

void static go_to_together_b(t_vars *vars, t_cost_result res_cost)
{
	if (res_cost.go == GO_TOGETHER)
	{
		if (res_cost.together.to == TO_UP)
		{
			while ((vars->a->top->index != res_cost.pivot->index)
				&& (vars->b->top->index != res_cost.target->index))
				rr(vars);
			while ((vars->a->top->index != res_cost.pivot->index))
				ra(vars);
			while((vars->b->top->index != res_cost.target->index))
				rb(vars);
		}
		if (res_cost.together.to == TO_DOWN)
		{
			while ((vars->a->top->index != res_cost.pivot->index)
				&& (vars->b->top->index != res_cost.target->index))
				rrr(vars);
			while ((vars->a->top->index != res_cost.pivot->index))
				rra(vars);
			while ((vars->b->top->index != res_cost.target->index))
				rrb(vars);
		}
	}
}

static void	go_to_alone_b(t_vars *vars, t_cost_result res_cost)
{
	if (res_cost.go == GO_ALONE)
	{
		if (res_cost.alone.pivot_to == TO_UP)
		{
			while (vars->a->top->index != res_cost.pivot->index)
				ra(vars);
		}
		if (res_cost.alone.pivot_to == TO_DOWN)
		{
			while (vars->a->top->index != res_cost.pivot->index)
				rra(vars);
		}
		if (res_cost.alone.target_to == TO_UP)
		{
			while (vars->b->top->index != res_cost.target->index)
				rb(vars);
		}
		if (res_cost.alone.target_to == TO_DOWN)
		{
			while (vars->b->top->index != res_cost.target->index)
				rrb(vars);
		}
	}
}

void	sort_all_b(t_vars *vars)
{
	t_cost_result	res_cost;

	pb(vars);
	pb(vars);
	while (vars->a->total > 0)
	{
		res_cost = find_cheapest(vars->a, vars->b);
		go_to_together_b(vars, res_cost);
		go_to_alone_b(vars, res_cost);
		pb(vars);
	}
}

void	sort_all_a(t_vars *vars)
{
	while (vars->b->total > 0)
	{
		move_max_to_top(vars);
		pa(vars);
	}
}
