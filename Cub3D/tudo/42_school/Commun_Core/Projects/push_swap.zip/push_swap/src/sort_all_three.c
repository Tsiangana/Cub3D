/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_all_three.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 03:15:25 by pzau              #+#    #+#             */
/*   Updated: 2024/09/13 03:15:26 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

int	get_max_value(int n1, int n2)
{
	if (n1 > n2)
		return (n1);
	return (n2);
}

t_node	*find_target(t_stack *stack, t_node *pivot)
{
	t_node	*min;
	t_node	*max;

	min = find_min(stack);
	max = find_max(stack);
	if ((pivot->value < min->value) || (pivot->value > max->value))
		return (max);
	return (find_min_closest(stack, pivot->value));
}

t_cost_go_alone	set_info_alone(int cost, int pivot_to, int target_to)
{
	t_cost_go_alone	res;

	res.cost = cost;
	res.pivot_to = pivot_to;
	res.target_to = target_to;
	return (res);
}

t_node	*find_min_closest(t_stack *stack, int pivot)
{
	t_node	*current;
	t_node	*min;

	if (stack->top == NULL)
		return (NULL);
	min = find_min(stack);
	current = stack->top;
	while (current != NULL)
	{
		if (min->value < current->value && current->value < pivot)
			min = current;
		current = current->previous;
	}
	return (min);
}