/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_all_two.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/13 02:21:55 by pzau              #+#    #+#             */
/*   Updated: 2024/09/13 02:22:02 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static t_pre_cost	pre_cost(t_stack *sp, t_stack *st, t_node *p, t_node *t)
{
	t_pre_cost	result;

	result.up_pivot = p->index;
	result.down_pivot = (sp->total - p->index);
	result.up_target = t->index;
	result.down_target = (st->total - t->index);
	result.target = t;
	result.pivot = p;
	return (result);
}

static t_cost_go_together	best_cost_go_together(t_pre_cost value)
{
	t_cost_go_together	res;

	if (get_max_value(value.up_target, value.up_pivot)
		<= get_max_value(value.down_target, value.down_pivot))
	{
		res.cost = get_max_value(value.up_target, value.up_pivot);
		res.to = TO_UP;
	}
	else
	{
		res.cost = get_max_value(value.down_target, value.down_pivot);
		res.to = TO_DOWN;
	}
	return (res);
}

static t_cost_go_alone	best_cost_go_alone(t_pre_cost value, t_stack *sp, t_stack *st)
{
	t_cost_go_alone	res;

	if (value.pivot->index <= get_half(sp))
	{
		if (value.target->index > get_half(st))
			res = set_info_alone((value.up_pivot + value.down_target), TO_UP, TO_DOWN);
		else
			res = set_info_alone((value.up_pivot + value.up_target), TO_UP, TO_UP);
	}
	else
	{
		if (value.target->index <= get_half(st))
			res = set_info_alone((value.down_pivot + value.up_target), TO_DOWN, TO_UP);
		else
			res = set_info_alone((value.down_pivot + value.down_target), TO_DOWN, TO_DOWN);
	}
	return (res);
	
}

t_cost_result	find_cost(t_stack *sp, t_stack *st, t_node *pivot)
{
	t_cost_result		res;
	t_node				*target;
	t_pre_cost			p_cost;
	t_cost_go_together	togeth;
	t_cost_go_alone		alone;

	target = find_target(st, pivot);
	p_cost = pre_cost(sp, st, pivot, target);
	alone = best_cost_go_alone(p_cost, sp, st);
	togeth = best_cost_go_together(p_cost);
	if ((togeth.cost <= alone.cost) && (p_cost.pivot->index != 0) && (p_cost.target->index != 0))
	{
		res.cost = togeth.cost;
		res.together = togeth;
		res.go = GO_TOGETHER;
	}
	else
	{
		res.cost = alone.cost;
		res.alone = alone;
		res.go = GO_ALONE;
	}
	set_target_pivot(&res, target, pivot);
	return (res);
}

t_cost_result	find_cheapest(t_stack *sp, t_stack *st)
{
	t_node			*current;
	t_cost_result	final_cost;
	t_cost_result	current_cost;

	current = sp->top;
	current_cost = find_cost(sp, st, current);\
	final_cost = current_cost;
	while (current)
	{
		current_cost = find_cost(sp, st, current);
		if (final_cost.cost > current_cost.cost)
			final_cost = current_cost;
		current = current->previous;
	}
	return (final_cost);
}
