/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_ff.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/12 20:56:32 by pzau              #+#    #+#             */
/*   Updated: 2024/09/12 20:56:34 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

static void case_1(t_vars *vars)
{
	if (vars->a->top->previous->value < vars->a->top->previous->previous->value)
		ra(vars);
	else
	{
		sa(vars);
		rra(vars);
	}
}

static void	case_2(t_vars *vars)
{
	if (vars->a->top->value > vars->a->top->previous->previous->value)
		rra(vars);
	else
	{
		rra(vars);
		sa(vars);
    }
}

void    sort_3(t_vars *vars)
{
    if ((vars->a->top->value > vars->a->top->previous->value) && (vars->a->top->value > vars->a->top->previous->previous->value))
        case_1(vars);
    else if ((vars->a->top->value > vars->a->top->value) && (vars->a->top->previous->value > vars->a->top->previous->previous->value))
        case_2(vars);
    else if ((vars->a->top->previous->previous->value > vars->a->top->value) && (vars->a->top->previous->previous->value > vars->a->top->previous->value))
    {
        if (vars->a->top->value > vars->a->top->previous->value)
            sa(vars);
    }
}
