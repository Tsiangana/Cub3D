/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   use_for_stack.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/07 14:12:45 by pzau              #+#    #+#             */
/*   Updated: 2024/09/07 14:12:47 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../headers/header.h"

void    free_stack(t_stack *stack)
{
    t_node  *current;
    t_node  *next_node;

    if (!stack)
        return ;
    current = stack->top;
    while (current)
    {
        next_node = current->previous;
        free(current);
        current = next_node;
    }
    free(stack);
}
