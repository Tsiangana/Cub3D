/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   animation.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/08 14:01:34 by pzau              #+#    #+#             */
/*   Updated: 2024/08/09 12:28:35 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	move_enemy(t_vars *vars)
{
	int	y;
	int	x;
	int	new_x;

	if (vars->current_screen == 0)
		return ;
	usleep(4000);
	vars->frame_count++;
	if (vars->frame_count < 100)
		return ;
	vars->frame_count = 0;
	y = 0;
	while (y < vars->dim.altura)
	{
		x = 0;
		while (x < vars->dim.largura)
		{
			if (vars->map[y][x] == 'M')
			{
				new_x = x + vars->direction;
				if (new_x >= 0 && new_x < vars->dim.largura && vars->map[y][new_x] == '0')
				{
					vars->map[y][x] = '0';
					vars->map[y][new_x] = 'M';
					x = new_x;
				}
			}
			x++;
		}
		y++;
	}
	vars->moves++;
	if (vars->moves == 3)
	{
		vars->direction = -vars->direction;
		vars->moves = 0;
	}
	render_map(vars, vars->map, vars->dim);
}

void	move_enemy_one(t_vars *vars)
{
	int	x;
	int	y;
	int	new_x;

	if (vars->current_screen == 0)
		return ;
	usleep(4000);
	vars->frame_count++;
	if (vars->frame_count < 100)
		return ;
	vars->frame_count = 0;
	y = 0;
	while (y < vars->dim.altura)
	{
		x = 0;
		while (x < vars->dim.largura)
		{
			if (vars->map[y][x] == 'M')
			{
				new_x = x + vars->direction;
				if (new_x >= 0 && new_x < vars->dim.largura && vars->map[y][new_x] == '0')
				{
					vars->map[y][x] = '0';
					vars->map[y][new_x] = 'M';
					x = new_x;
				}
			}
			x++;
		}
		y++;
	}
	vars->moves++;
	if (vars->moves == 3)
	{
		vars->direction = -vars->direction;
		vars->moves = 0;
	}
	render_map_one(vars, vars->map, vars->dim);
}

void	move_enemy_two(t_vars *vars)
{
	int	x;
	int	y;
	int	new_x;

	if (vars->current_screen == 0)
		return ;
	usleep(4000);
	vars->frame_count++;
	if (vars->frame_count < 100)
		return ;
	vars->frame_count = 0;
	y = 0;
	while (y < vars->dim.altura)
	{
		x = 0;
		while (x < vars->dim.largura)
		{
			if (vars->map[y][x] == 'M')
			{
				new_x = x + vars->direction;
				if (new_x >= 0 && new_x < vars->dim.largura && vars->map[y][new_x] == '0')
				{
					vars->map[y][x] = '0';
					vars->map[y][new_x] = 'M';
					x = new_x;
				}
			}
			x++;
		}
		y++;
	}
	vars->moves++;
	if (vars->moves == 3)
	{
		vars->direction = -vars->direction;
		vars->moves = 0;
	}
	render_map_two(vars, vars->map, vars->dim);
}
