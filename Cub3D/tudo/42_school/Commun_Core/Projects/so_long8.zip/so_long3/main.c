/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pzau <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 12:01:34 by pzau              #+#    #+#             */
/*   Updated: 2024/08/09 16:39:21 by pzau             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int	main(void)
{
	t_vars	vars;
	t_vals	vals;

	vars.mlx = mlx_init();
	vars.win = mlx_new_window(vars.mlx, 900, 519, "so_long");
	vals.pin_level = 0;
	init_image(&vars);
	draw_small_image(&vars);
	mlx_mouse_hook(vars.win, iniciar, &vars);
	mlx_hook(vars.win, 17, 0, close_new_window, &vars);
	mlx_key_hook(vars.win, key_esc, &vars);
	gamestart();
	mlx_loop(vars.mlx);
	return (0);
}
