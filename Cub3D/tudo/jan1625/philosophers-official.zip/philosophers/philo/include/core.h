/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   core.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mebaptis <mebaptis@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/29 15:52:06 by mebaptis          #+#    #+#             */
/*   Updated: 2024/10/02 13:30:22 by mebaptis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CORE_H
# define CORE_H
# include <stdlib.h>
# include <unistd.h>
# include <stdarg.h>
# include <fcntl.h>
# include <limits.h>
# include <pthread.h>
# include <stddef.h>
# include <stdio.h>
# include <sys/time.h>

# define FORK 0
# define DIED 1
# define SLEEP 2
# define EATING 3
# define THINKING 4

typedef struct s_manager_tex {
	pthread_mutex_t	prinft;
	pthread_mutex_t	current_time;
	pthread_mutex_t	last_eat;
	pthread_mutex_t	running;
	pthread_mutex_t	all_eat;
}		t_manager_tex;

typedef struct s_monitor {
	int		running;
}		t_monitor;

typedef struct s_parameters {
	int	num_of_philos;
	int	time_to_die;
	int	time_to_eat;
	int	time_to_sleep;
	int	limit_of_philo_eat;
}		t_parameters;

typedef struct s_philosopher {
	pthread_mutex_t	*left_fork;
	pthread_mutex_t	*right_fork;
	t_manager_tex	*manager;
	t_parameters	*parameters;
	t_monitor		*monitor;
	int				*eat_limit;
	int				id;
	int				died;
	size_t			eat_times;
	size_t			last_times_eat;
	size_t			init_time;
	pthread_t		thread;
}		t_philosopher;

typedef struct s_context {
	pthread_mutex_t		*forks;
	t_philosopher		*philos;
	int					*eat_limit;
	t_parameters		parameters;
	t_manager_tex		manager;
	t_monitor			monitor;
	pthread_t			thread_monitor;
}		t_context;

t_parameters	get_parameters(int argc, char *argv[]);
t_context		*init_context(t_parameters parameters);
long			ft_atoi(const char *str);
size_t			current_time(void);
int				is_number(char *str);
int				ft_short_printf(const char *format, ...);
int				all_eat_limit(t_philosopher *philo);
int				has_morte(t_philosopher *philo);
void			*routines_one_philo(void *arg);
void			philo_actions(t_philosopher *philo, int flag);
void			*philo_routines(void *arg);
void			managenment_philo(t_philosopher *philo, int flag);
void			dispose(t_context *c);
void			*manager_philos(void *arg);
#endif
