/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   context.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mebaptis <mebaptis@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/20 14:37:49 by mebaptis          #+#    #+#             */
/*   Updated: 2024/10/02 13:12:33 by mebaptis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core.h"

static void	set_philo_info(t_context *c, size_t current_tm, int i)
{
	c->philos[i].id = i + 1;
	c->philos[i].died = 0;
	c->philos[i].eat_times = 0;
	c->philos[i].manager = &c->manager;
	c->philos[i].parameters = &c->parameters;
	c->philos[i].monitor = &c->monitor;
	c->philos[i].eat_limit = c->eat_limit;
	c->philos[i].last_times_eat = current_tm;
	c->philos[i].init_time = current_tm;
	c->philos[i].right_fork = &c->forks[i];
	c->philos[i].left_fork = &c->forks[(i + 1) % c->parameters.num_of_philos];
	pthread_create(&c->philos[i].thread, NULL, philo_routines, &c->philos[i]);
}

static t_manager_tex	init_manager_tex(void)
{
	t_manager_tex	manager;

	pthread_mutex_init(&manager.all_eat, NULL);
	pthread_mutex_init(&manager.current_time, NULL);
	pthread_mutex_init(&manager.prinft, NULL);
	pthread_mutex_init(&manager.last_eat, NULL);
	pthread_mutex_init(&manager.running, NULL);
	return (manager);
}

static int	init_fork_and_philos(t_context *c)
{
	int		i;
	size_t	current_tm;

	c->forks = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t)
			* c->parameters.num_of_philos);
	c->philos = (t_philosopher *)malloc(sizeof(t_philosopher)
			* c->parameters.num_of_philos);
	c->eat_limit = (int *)malloc(sizeof(int) * c->parameters.num_of_philos);
	if (!c->forks || !c->philos || !c->eat_limit)
		return (0);
	i = 0;
	while (i < c->parameters.num_of_philos)
	{
		pthread_mutex_init(&(c->forks[i]), NULL);
		c->eat_limit[i] = 0;
		i++;
	}
	i = 0;
	current_tm = current_time();
	while (i < c->parameters.num_of_philos)
	{
		set_philo_info(c, current_tm, i);
		i++;
	}
	return (1);
}

t_context	*init_context(t_parameters parameters)
{
	t_context	*context;

	context = (t_context *)malloc(sizeof(t_context));
	if (!context)
		return (NULL);
	context->parameters = parameters;
	context->manager = init_manager_tex();
	context->monitor.running = 1;
	if (!init_fork_and_philos(context))
		return (NULL);
	if (context->parameters.num_of_philos > 1)
		pthread_create(&context->thread_monitor, NULL, manager_philos, context);
	return (context);
}

void	dispose(t_context *c)
{
	int	i;

	i = 0;
	if (c->parameters.num_of_philos > 1)
		pthread_join(c->thread_monitor, NULL);
	while (i < c->parameters.num_of_philos)
	{
		if (c->philos[i].thread)
			pthread_join(c->philos[i].thread, NULL);
		i++;
	}
	i = 0;
	while (i < c->parameters.num_of_philos)
	{
		pthread_mutex_destroy(&(c->forks[i]));
		i++;
	}
	free(c->eat_limit);
	free(c->forks);
	free(c->philos);
	free(c);
}
