/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mebaptis <mebaptis@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/19 15:56:31 by mebaptis          #+#    #+#             */
/*   Updated: 2024/10/01 17:08:58 by mebaptis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core.h"

int	main(int argc, char *argv[])
{
	t_context		*context;
	t_parameters	parameters;

	parameters = get_parameters(argc, argv);
	if (parameters.num_of_philos < 1
		|| parameters.time_to_die < 1
		|| parameters.time_to_eat < 1
		|| parameters.time_to_sleep < 1)
	{
		printf("Error: Invalid arguments!\n");
		return (1);
	}
	if (parameters.num_of_philos > 200)
	{
		printf("Error: Invalid philosopher number!\n");
		return (1);
	}
	context = init_context(parameters);
	if (!context)
	{
		printf("Unexpected error!\n");
		return (1);
	}
	dispose(context);
	return (0);
}
