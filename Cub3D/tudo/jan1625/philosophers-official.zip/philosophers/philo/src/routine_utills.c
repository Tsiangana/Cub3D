/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   routine_utills.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mebaptis <mebaptis@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/30 12:35:16 by mebaptis          #+#    #+#             */
/*   Updated: 2024/10/02 13:42:10 by mebaptis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core.h"

static void	eating_actions(t_philosopher *philo)
{
	printf("[%ld] %d is eating\n", current_time()
		- philo->init_time, philo->id);
	philo->eat_times++;
	if ((philo->parameters->limit_of_philo_eat > 0)
		&& (philo->eat_times == (size_t)philo->parameters->limit_of_philo_eat))
	{
		pthread_mutex_lock(&philo->manager->all_eat);
		philo->eat_limit[philo->id - 1] = 1;
		pthread_mutex_unlock(&philo->manager->all_eat);
	}
}

void	philo_actions(t_philosopher *philo, int flag)
{
	if (flag == FORK)
		printf("[%ld] %d has taken a fork\n", current_time()
			- philo->init_time, philo->id);
	if (flag == SLEEP)
		printf("[%ld] %d is sleeping\n", current_time()
			- philo->init_time, philo->id);
	if (flag == THINKING)
		printf("[%ld] %d is thinking\n", current_time()
			- philo->init_time, philo->id);
	if (flag == DIED)
		printf("[%ld] %d has died\n", current_time()
			- philo->init_time, philo->id);
	if (flag == EATING)
		eating_actions(philo);
}

void	managenment_philo(t_philosopher *philo, int flag)
{
	if (philo->eat_limit[philo->id - 1])
		return ;
	pthread_mutex_lock(&philo->manager->prinft);
	pthread_mutex_lock(&philo->manager->running);
	if (!philo->monitor->running)
	{
		pthread_mutex_unlock(&philo->manager->running);
		pthread_mutex_unlock(&philo->manager->prinft);
		return ;
	}
	pthread_mutex_unlock(&philo->manager->running);
	philo_actions(philo, flag);
	pthread_mutex_unlock(&philo->manager->prinft);
}

int	has_morte(t_philosopher *philo)
{
	pthread_mutex_lock(&philo->manager->last_eat);
	if ((current_time() - philo->last_times_eat)
		> (size_t)philo->parameters->time_to_die + 3)
	{
		pthread_mutex_unlock(&philo->manager->last_eat);
		managenment_philo(philo, DIED);
		pthread_mutex_lock(&philo->manager->running);
		philo->monitor->running = 0;
		pthread_mutex_unlock(&philo->manager->running);
		return (1);
	}
	pthread_mutex_unlock(&philo->manager->last_eat);
	return (0);
}

int	all_eat_limit(t_philosopher *philo)
{
	int	i;

	pthread_mutex_lock(&philo->manager->all_eat);
	i = 0;
	while (i < philo->parameters->num_of_philos)
	{
		if (philo->eat_limit[i] == 0)
		{
			pthread_mutex_unlock(&philo->manager->all_eat);
			return (0);
		}
		i++;
	}
	pthread_mutex_unlock(&philo->manager->all_eat);
	pthread_mutex_lock(&philo->manager->running);
	philo->monitor->running = 0;
	pthread_mutex_unlock(&philo->manager->running);
	return (1);
}
