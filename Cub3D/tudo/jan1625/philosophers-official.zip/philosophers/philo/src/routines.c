/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   routines.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mebaptis <mebaptis@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/23 17:44:49 by mebaptis          #+#    #+#             */
/*   Updated: 2024/10/02 13:41:24 by mebaptis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core.h"

static int	has_one_philo_only(t_philosopher *philo)
{
	if (philo->parameters->num_of_philos == 1)
	{
		pthread_mutex_lock(philo->right_fork);
		managenment_philo(philo, FORK);
		pthread_mutex_unlock(philo->right_fork);
		usleep(philo->parameters->time_to_die * 1000);
		managenment_philo(philo, DIED);
		return (1);
	}
	return (0);
}

static void	taken_fork(t_philosopher *philo)
{
	if (philo->id % 2 == 0)
	{
		usleep(1000);
		pthread_mutex_lock(philo->left_fork);
		managenment_philo(philo, FORK);
		pthread_mutex_lock(philo->right_fork);
		managenment_philo(philo, FORK);
	}
	else
	{
		pthread_mutex_lock(philo->right_fork);
		managenment_philo(philo, FORK);
		pthread_mutex_lock(philo->left_fork);
		managenment_philo(philo, FORK);
	}
}

void	*manager_philos(void *arg)
{
	t_context		*c;
	t_philosopher	*philo;
	int				i;

	c = (t_context *)arg;
	i = 0;
	while (1)
	{
		usleep(100);
		if (!c->monitor.running)
			break ;
		i = 0;
		while (i < c->parameters.num_of_philos)
		{
			philo = &c->philos[i];
			if (has_morte(philo))
				break ;
			if (all_eat_limit(philo))
				break ;
			i++;
		}
	}
	return (NULL);
}

static void	philo_routines_usefull(t_philosopher *philo)
{
	taken_fork(philo);
	managenment_philo(philo, EATING);
	usleep(philo->parameters->time_to_eat * 1000);
	pthread_mutex_lock(&philo->manager->last_eat);
	philo->last_times_eat = current_time();
	pthread_mutex_unlock(&philo->manager->last_eat);
	pthread_mutex_unlock(philo->left_fork);
	pthread_mutex_unlock(philo->right_fork);
	managenment_philo(philo, SLEEP);
	usleep((philo->parameters->time_to_sleep) * 1000);
	managenment_philo(philo, THINKING);
}

void	*philo_routines(void *arg)
{
	t_philosopher	*philo;

	philo = (t_philosopher *)arg;
	while (1)
	{
		pthread_mutex_lock(&philo->manager->running);
		if (!philo->monitor->running)
		{
			pthread_mutex_unlock(&philo->manager->running);
			break ;
		}
		pthread_mutex_unlock(&philo->manager->running);
		if (has_one_philo_only(philo))
			break ;
		philo_routines_usefull(philo);
	}
	return (NULL);
}
