/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   usefull_1.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mebaptis <mebaptis@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/19 16:19:11 by mebaptis          #+#    #+#             */
/*   Updated: 2024/09/30 12:44:54 by mebaptis         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "core.h"

size_t	current_time(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return ((tv.tv_usec / 1000) + (tv.tv_sec * 1000));
}

int	is_number(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if ((str[i] < '0') || (str[i] > '9'))
			return (0);
		i++;
	}
	return (1);
}

t_parameters	get_parameters(int argc, char *argv[])
{
	int				i;
	t_parameters	res;

	res.num_of_philos = 0;
	res.time_to_die = 0;
	res.time_to_eat = 0;
	res.time_to_sleep = 0;
	res.limit_of_philo_eat = 0;
	i = 1;
	if ((argc < 5) || (argc > 6))
		return (res);
	while (i < argc)
	{
		if (!is_number(argv[i]))
			return (res);
		i++;
	}
	res.num_of_philos = ft_atoi(argv[1]);
	res.time_to_die = ft_atoi(argv[2]);
	res.time_to_eat = ft_atoi(argv[3]);
	res.time_to_sleep = ft_atoi(argv[4]);
	if (argc == 6)
		res.limit_of_philo_eat = ft_atoi(argv[5]);
	return (res);
}
